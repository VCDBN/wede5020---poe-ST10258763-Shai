document.addEventListener('DOMContentLoaded', function() {
  var navigationLinks = document.querySelectorAll('.topnav a');

  navigationLinks.forEach(function(link) {
    link.addEventListener('click', function(event) {

      navigationLinks.forEach(function(navLink) {
        navLink.classList.remove('active');
      });


      link.classList.add('active');


      console.log(link.textContent + ' link clicked!');
    });
  });

  const treeFacts = [
    "Trees produce oxygen and absorb carbon dioxide.",
    "Trees can help reduce energy costs by providing shade in the summer.",
    "Some tree species can live for thousands of years.",
    "Trees help prevent soil erosion.",
    "Trees provide habitat for a variety of wildlife species."
  ];

  const factButton = document.getElementById('factButton');
  const factDisplay = document.getElementById('factDisplay');

  factButton.addEventListener('click', function() {

    const randomIndex = Math.floor(Math.random() * treeFacts.length);
    const randomFact = treeFacts[randomIndex];

    factDisplay.textContent = randomFact;
  });
});






